﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Organizer
{
    public partial class _frmManageEvents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            name = Session["User"].ToString();
            if (!this.IsPostBack)
            {
                getProf();
                getType();
                ViewGV();
            }
        }

        BL b = new BL();
        string name;
        DataTable tab = new DataTable();

        private void getProf()
        {
            Image1.ImageUrl = b.getOrgPic(name);
            Label1.Text = "Welcome " + b.getOrgName(name);
            Label1.ForeColor = System.Drawing.Color.Brown;
        }

        private void getType()
        {
            tab = b.getEvType();
            ddlType.DataSource = tab;
            ddlType.DataTextField = "Ev_Type";
            ddlType.DataValueField = "Ev_Id";
            ddlType.DataBind();
            ListItem lis = new ListItem("Select", "-1");
            ddlType.Items.Insert(0, "Select");
        }

        private void ViewGV()
        {
            DataTable tab = b.getEvDet();
            if (tab.Rows.Count > 0)
            {
                GridView2.DataSource = tab;
                GridView2.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No Records Found..')</script>");
            }
        }

        protected void Edit_Click(object sender, ImageClickEventArgs e)
        {
            GridViewRow r = (GridViewRow)((ImageButton)sender).Parent.Parent;
            evid = (((ImageButton)sender).CommandArgument);
            Button1.Text = "Update";

            evid = r.Cells[1].Text;
            txtName.Text = r.Cells[2].Text;
            txtVenu.Text = r.Cells[3].Text;
            txtDate.Text = r.Cells[4].Text;
            ListItem lis = new ListItem();
            lis.Text = r.Cells[5].Text;
            
            int index = ddlType.Items.IndexOf(lis);
            ddlType.SelectedIndex = index;
            txtFee.Text = r.Cells[6].Text;
            txtDescription.Text = r.Cells[7].Text;
        }

        protected void Delete_Click(object sender, ImageClickEventArgs e)
        {
            int eid = int.Parse(((ImageButton)sender).CommandArgument);
            if (b.deleteEvDet(eid) == 1)
            {
                Response.Write("<string>confirm('Are you going to delete this Record?..')</string>");
            }
            else
            {
                Response.Write("<string>alert('Error in deleting Record..')</string>");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int usrId = b.getUsrId(name);
            string type = ddlType.SelectedItem.Value;
            if (Button1.Text == "ADD")
            {
                if (b.insertEvDet(usrId, txtName.Text, txtVenu.Text, txtDate.Text, int.Parse(type), txtFee.Text, txtDescription.Text) == 1)
                {
                    Response.Write("<script>alert('Event Details Inserted Sucessfully..')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Error in Adding Event Details..')</script>");
                }
            }
            else
            {
                if (b.updateEvDet(txtName.Text, txtVenu.Text, txtDate.Text, int.Parse(type), txtFee.Text, txtDescription.Text, int.Parse(evid)) == 1)
                {
                    Response.Write("<script>alert('Event Details Updated Sucessfully..')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Error in Updating Event Details..')</script>");
                }
                Button1.Text = "ADD";
            }
            reset();
            ViewGV();
        }

        private static string evid { get; set; }
        //private static string id { get; set; }

        private void reset()
        {
            txtName.Text = "";
            txtVenu.Text = "";
            txtDate.Text = "";
            txtFee.Text = "";
            txtDescription.Text = "";
            ddlType.SelectedIndex = -1;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtVenu.Text = "";
            txtDate.Text = "";
            txtFee.Text = "";
            txtDescription.Text = "";
            ddlType.SelectedIndex = -1;
        }

        protected void Del_Click(object sender, ImageClickEventArgs e)
        {
            int eid = int.Parse(((ImageButton)sender).CommandArgument);
            if (b.deleteEvDet(eid) == 1)
            {
                Response.Write("<string>confirm('Are you going to delete this Record?..')</string>");
            }
            else
            {
                Response.Write("<string>alert('Error in deleting Record..')</string>");
            }
            ViewGV();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            int eid = int.Parse(((ImageButton)sender).CommandArgument);
            if (b.deleteEvDet(eid) == 1)
            {
                Response.Write("<string>confirm('Are you going to delete this Record?..')</string>");
            }
            else
            {
                Response.Write("<string>alert('Error in deleting Record..')</string>");
            }
            ViewGV();
        }

 
        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    GridViewRow r = (GridViewRow)((Button)sender).Parent.Parent;
        //    //id = (((Button)sender).CommandArgument);
        //    Button1.Text = "Update";
        //    evid = r.Cells[0].Text;
        //    txtName.Text = r.Cells[1].Text;
        //    txtVenu.Text = r.Cells[2].Text;
        //    txtDate.Text = r.Cells[3].Text;
        //    ListItem lis = new ListItem();
        //    lis.Text = r.Cells[4].Text;
        //    int index = ddlType.Items.IndexOf(lis);
        //    ddlType.SelectedIndex = index;
        //    txtFee.Text = r.Cells[5].Text;
        //    txtDescription.Text = r.Cells[6].Text;
        //}
    }
}