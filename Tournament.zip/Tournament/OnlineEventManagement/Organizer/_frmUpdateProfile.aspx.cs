﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Organizer
{
    public partial class _frmUpdateProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            usr=Session["User"].ToString();
            if (!this.IsPostBack)
            {
                getProf();
                ViewProfile();
            }
        }

        BL b = new BL();
        static string usr;
        static DataTable tab = new DataTable();

        private void getProf()
        {
            Image1.ImageUrl = b.getOrgPic(usr);
            Label1.Text = "Welcome " + b.getOrgName(usr);
        }

        private void ViewProfile()
        {
            MultiView1.SetActiveView(View1);
            tab = b.getOrgProf(usr);
            lblName.Text = tab.Rows[0][1].ToString();
            lblContNo.Text = tab.Rows[0][2].ToString();
            lblAddres.Text = tab.Rows[0][7].ToString();
            lblQualification.Text = tab.Rows[0][8].ToString();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.SetActiveView(View2);
            txtName.Text = tab.Rows[0][1].ToString();
            txtContNo.Text = tab.Rows[0][2].ToString();
            txtAddres.Text = tab.Rows[0][7].ToString();
            txtQual.Text = tab.Rows[0][8].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (b.updateProfile(txtName.Text, txtContNo.Text, txtAddres.Text, txtQual.Text,usr) == 1)
            {
                Response.Write("<script>alert('Profile Updated Sucessfully..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in Profile Updating..')</script>");
            }
            reset();
        }

        private void reset()
        {
            txtName.Text = "";
            txtContNo.Text = "";
            txtAddres.Text = "";
            txtQual.Text = "";
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            ViewProfile();
        }
    }
}