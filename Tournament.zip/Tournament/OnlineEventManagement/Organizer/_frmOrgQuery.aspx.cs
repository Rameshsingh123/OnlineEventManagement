﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Organizer
{
    public partial class _frmOrgQuery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                ViewGV();
            }
        }

        BL b = new BL();
        static string txt;
        static int id2;

        private void ViewGV()
        {
            DataTable tab = b.getQueries();
            if(tab.Rows.Count > 0)
            {
                GridView1.DataSource=tab;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No record found..')</script>");
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow r = (GridViewRow)((CheckBox)sender).Parent.Parent;
            //int id=int.Parse(((CheckBox)sender).Checked.ToString());  Check box commandargument not saported..
            Label id1 = (Label)r.FindControl("Label1");
            id2 = int.Parse(id1.Text);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dat = DateTime.Now.ToString("dd/MM/yyyy");
            if (b.updateQuery(txtQuery.Text, dat, id2) == 1)
            {
                Response.Write("<script>alert('Query Posted..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in Query Posting..')</script>");
            }
            txtQuery.Text = "";
            ViewGV();
        }
    }
}