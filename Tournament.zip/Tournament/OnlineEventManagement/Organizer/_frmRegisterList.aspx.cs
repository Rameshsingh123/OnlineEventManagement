﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Organizer
{
    public partial class _frmRegisterList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            name=Session["User"].ToString();
            if (!this.IsPostBack)
            {
                getEvType1();
            }
        }

        BL b = new BL();
        static string name;

        private void getEvType1()
        {
            ddlEvType.DataSource = b.getEvType();
            ddlEvType.DataTextField = "EV_Type";
            ddlEvType.DataValueField = "Ev_Id";
            ddlEvType.DataBind();
            ListItem li = new ListItem("Select","-1");
            ddlEvType.Items.Insert(0,"Select");
        }

        private void getEvName1()
        {
            string et = ddlEvType.SelectedItem.Value;
            int usrId = b.getUsrId(name);
            DataTable tab = b.getEvName(int.Parse(et), usrId);
            //if (tab.Rows.Count > 0)
            //{
                ddlEvName.DataSource = tab;
                ddlEvName.DataTextField = "Ev_Name";
                ddlEvName.DataValueField = "Evt_Id";
                ddlEvName.DataBind();
                ListItem li = new ListItem("Select", "-1");
                ddlEvName.Items.Insert(0, "Select");
            //}
            //else
            //{
            //    Label3.Text = "No events name are present in that type..";
            //    Label3.ForeColor = System.Drawing.Color.Brown;
            //}
        }

        private void ViewGV()
        {
            string evtId = ddlEvType.SelectedItem.Value;
            string evId = ddlEvName.SelectedItem.Value;
            DataTable tab = b.getUsrReg(int.Parse(evId),int.Parse(evtId));
            if (tab.Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = tab;
                GridView1.DataBind();
               
            }
            else
            {
                GridView1.Visible = false;
                Response.Write("<script>alert('No record found..')</script>");
            }
        }

        protected void ddlEvType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEvType.SelectedIndex != 0)
            {
                getEvName1();
            }
        }

        protected void ddlEvName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlEvName.SelectedIndex != 0)
            {
                ViewGV();
            }
        }

        static string reg_Id = null;
        static string[] reg_Id1 = null;
 
        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow r = (GridViewRow)((CheckBox)sender).NamingContainer;
            int index = r.RowIndex;
            CheckBox cb = (CheckBox)GridView1.Rows[index].FindControl("CheckBox1");
            string id = cb.Text;
            if (cb.Checked == true)
            {
                reg_Id = reg_Id + id + ",";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            reg_Id1 = reg_Id.Split(',');
            reg_Id1 = reg_Id1.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            for (int i = 0; i <= reg_Id1.Count()-1; i++)
            {
                string id = reg_Id1[i];
                string sts = "Approve";
                if (b.updateReg(sts, txtReason.Text, id) == 1)
                {
                    //Response.Write("<script>alert('Record updated sucessfully..')</script>");
                    Label4.Text = "Record updated sucessfully..";
                    Label4.ForeColor = System.Drawing.Color.Brown;
                }
                else
                {
                    Response.Write("<script>alert('Error in Updating..')</script>");
                }
            }
            txtReason.Text = "";
            ViewGV();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            reg_Id1 = reg_Id.Split(',');
            reg_Id1 = reg_Id1.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            for (int i = 0; i <= reg_Id1.Count() - 1; i++)
            {
                string id = reg_Id1[i];
                string sts = "Reject";
                if (b.updateReg(sts, txtReason.Text, id) == 1)
                {
                    //Response.Write("<script>alert('Record updated sucessfully..')</script>");
                    Label4.Text = "Record updated sucessfully..";
                    Label4.ForeColor = System.Drawing.Color.Brown;
                }
                else
                {
                    Response.Write("<script>alert('Error in Updating..')</script>");
                }
            }
            txtReason.Text = "";
            ViewGV();
        }
    }
}