﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineEventManagement.Visitor
{
    public partial class _frmLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        BL b = new BL();

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["User"] = txtLogin.Text;
            Session["Pswd"] = txtPassword.Text;
            string type = ddlType.SelectedItem.Text;
            if (b.IsValied(type, txtLogin.Text, txtPassword.Text) == true)
            {
                if (type == "Admin")
                    Response.Redirect("~/Admin/_frmAdminHome.aspx");
                else
                    if (type == "Organizer")
                        Response.Redirect("~/Organizer/_frmOrganizerHome.aspx");
                    else
                        if (type == "User")
                            Response.Redirect("~/user/_frmUserHome.aspx");
            }
            else
                Response.Write("<Script>alert('Invalied UserId / Password..')</Script>");
        }
    }
}