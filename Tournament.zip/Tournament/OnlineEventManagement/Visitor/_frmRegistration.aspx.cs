﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    namespace OnlineEventManagement.Visitor
    {
        public partial class _frmRegistration : System.Web.UI.Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {

            }

            BL b = new BL();

            protected void Button1_Click(object sender, EventArgs e)
            {
                string type=ddlType.SelectedItem.Text;
                string path = "~/Visitor/Images/" + FileUpload1.FileName;
                FileUpload1.SaveAs(MapPath(path));
                string status = "Pending";
                if (b.eMailExit(txtEmailId.Text) == 1)
                {
                    lbleMail.Text = "eMail Already Exist.";
                }
                else
                {
                    if (b.insert(txtName.Text, txtContctNo.Text, txtEmailId.Text, path, txtPassword.Text, type, txtAddress.Text, txtQualification.Text, status) == 1)
                    {
                        Response.Write("<script>alert('Record Inserted Sucessfully..')</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Error in Inserting Record..')</script>");
                    }
                }
                reset();
            }

            private void reset()
            {
                txtName.Text = "";
                txtContctNo.Text = "";
                txtEmailId.Text = "";
                txtPassword.Text = "";
                txtAddress.Text = "";
                txtQualification.Text = "";
            }
        }
    }