﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Admin
{
    public partial class _frmViewRegisteredUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                ViewGV();
            }
        }

        BL b = new BL();
        static string userType = "User";

        private void ViewGV()
        {
            DataTable tab = b.getUsrRegDet(userType);
            if (tab.Rows.Count > 0)
            {
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No Record Found..')</script>");
            }
        }

        protected void Accept_Click(object sender, EventArgs e)
        {
            GridViewRow r = (GridViewRow)((Button)sender).Parent.Parent;
            int usrId = int.Parse(((Button)sender).CommandArgument);
            string sts = "Approved";
            if (b.updateUser(sts, usrId) == 1)
            {
                Response.Write("<script>alert('Record Updated Sucessfully..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in Record Updating..')</script>");
            }
            ViewGV();
        }

        protected void Reject_Click(object sender, EventArgs e)
        {
            GridViewRow r = (GridViewRow)((Button)sender).Parent.Parent;
            int usrId = int.Parse(((Button)sender).CommandArgument);
            string sts = "Reject";
            if (b.updateUser(sts, usrId) == 1)
            {
                Response.Write("<script>alert('Record Updated Sucessfully..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in Record Updating..')</script>");
            }
            ViewGV();
        }
    }
}