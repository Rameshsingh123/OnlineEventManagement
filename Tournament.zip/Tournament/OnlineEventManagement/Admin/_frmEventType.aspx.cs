﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Admin
{
    public partial class _frmEventType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                ViewGV();
            }
        }

        BL b = new BL();

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Button3.Text == "ADD")
            {
                if (b.insertEvType(txtEvType.Text) == 1)
                {
                    Response.Write("<script>alert('Event Type Added Sucessfully..')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Erroe in Adding Event Type..')</script>");
                }
            }
            else
            {
                if (b.updateEvType(txtEvType.Text, evId) == 1)
                {
                    Response.Write("<script>alert('Event Type Updated Sucessfully..')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Error in Updating Event Type..')</script>");
                }
                Button3.Text = "ADD";
            }
            txtEvType.Text = "";
            ViewGV();
        }

        protected void Edit_Click(object sender, ImageClickEventArgs e)
        {
            GridViewRow row = (GridViewRow)((ImageButton)sender).Parent.Parent;
            evId = (((ImageButton)sender).CommandArgument);
            Button3.Text = "Update";
            txtEvType.Text = row.Cells[1].Text;
        }

        protected void Delete_Click(object sender, ImageClickEventArgs e)
        {
            int eId = int.Parse(((ImageButton)sender).CommandArgument);
            if (b.delete(eId) == 1)
            {
                //ScriptManager.RegisterStartupScript(this,GetType(),"key","confirm('Are you sure you want to delete?');",true); 
                Response.Write("<script>alert('Record Deleted..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in Deleting Event Type..')</script>");
            }
            ViewGV();
        }

        public static string evId { get; set; }

        private void ViewGV()
        {
            DataTable tab=b.getEvType();
            if(tab.Rows.Count>0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
                else
                {
                    GridView1.Visible = false;
                    //Response.Write("<script>alert('No Records..')</script>");
                }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtEvType.Text = "";
        }
    }
}