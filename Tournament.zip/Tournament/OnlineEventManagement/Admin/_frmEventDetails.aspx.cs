﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.Admin
{
    public partial class _frmEventDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                getType();
                ViewGV();
            }
        }

        BL b = new BL();

        private void getType()
        {
            ddlType.DataSource = b.getEvType();
            ddlType.DataTextField = "Ev_Type";
            ddlType.DataValueField = "Ev_Id";
            ddlType.DataBind();
            ListItem lis = new ListItem("Select","-1");
            ddlType.Items.Insert(0,"Select");
        }

        private void ViewGV()
        {
            DataTable tab = b.getEvDet();
            if (tab.Rows.Count > 0)
            {
                GridView2.DataSource = tab;
                GridView2.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No Records Found..')</script>");
            }
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    string type=ddlType.SelectedItem.Value;
        //    if (Button1.Text == "ADD")
        //    {
        //        if (b.insertEvDet(txtName.Text, txtVenu.Text, txtDate.Text, int.Parse(type), txtFee.Text, txtDescription.Text) == 1)
        //        {
        //            Response.Write("<script>alert('Event Details Inserted Sucessfully..')</script>");
        //        }
        //        else
        //        {
        //            Response.Write("<script>alert('Error in Adding Event Details..')</script>");
        //        }
        //    }
        //    else
        //    {
        //        if (b.updateEvDet(txtName.Text, txtVenu.Text, txtDate.Text, int.Parse(type), txtFee.Text, txtDescription.Text, int.Parse(evid)) == 1)
        //        {
        //            Response.Write("<script>alert('Event Details Updated Sucessfully..')</script>");
        //        }
        //        else
        //        {
        //            Response.Write("<script>alert('Error in Updating Event Details..')</script>");
        //        }
        //    }
        //}

        
        private static string evid { get; set; }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('Hi..')</script>");
        }

       
        protected void Delete1_Click(object sender, ImageClickEventArgs e)
        {
            int eid = int.Parse(((ImageButton)sender).CommandArgument);
            if (b.deleteEvDet(eid) == 1)
            {
                Response.Write("<script>confirm('Are you going to delete this Record?..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in deleting Record..')</script>");
            }
        }

        protected void Edit_Click(object sender, ImageClickEventArgs e)
        {
            GridViewRow r = (GridViewRow)((ImageButton)sender).Parent.Parent;
            int eid = int.Parse(((ImageButton)sender).CommandArgument);
            Button1.Text = "Update";
            evid = r.Cells[0].Text;
            txtName.Text = r.Cells[1].Text;
            txtVenu.Text = r.Cells[2].Text;
            txtDate.Text = r.Cells[3].Text;
            ListItem lis = new ListItem();
            lis.Text = r.Cells[4].Text;
            int index = ddlType.Items.IndexOf(lis);
            ddlType.SelectedIndex = index;
            txtFee.Text = r.Cells[5].Text;
            txtDescription.Text = r.Cells[6].Text;
        }

    }
}