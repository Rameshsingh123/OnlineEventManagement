﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.User
{
    public partial class _frmPostFeedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            name=Session["User"].ToString();
            if (!this.IsPostBack)
            {
                ViewGV();
            }
        }

        BL b = new BL();
        string name;
        static int usrid;

        private void ViewGV()
        {
            usrid = b.getUsrId(name);
            DataTable tab = b.getFeedback1(usrid);
            if (tab.Rows.Count > 0)
            {
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No record found..')</script>");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dat=DateTime.Now.ToString("dd/MM/yyyy");
            if(b.insertFB(usrid,txtFeedback.Text,dat)==1)
            {
                Response.Write("<script>alert('Recort inserted sucessfully..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in inserting record..')</script>");
            }
            txtFeedback.Text="";
            ViewGV();
        }
    }
}