﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.User
{
    public partial class _frmGetRegEvent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            name=Session["User"].ToString();
            if (!this.IsPostBack)
            {
                getProf();
                getType();
                //ViewGV();
            }
        }

        BL b = new BL();
        static string name;
        static int edid, usrid,id4;

        private void getProf()
        {
            Image1.ImageUrl = b.getOrgPic(name);
            Label3.Text = "Welcome " + b.getOrgName(name);
            Label3.ForeColor = System.Drawing.Color.Brown;
        }

        private void getType()
        {
            //string id = ddlType.SelectedItem.Value;
            ddlType.DataSource = b.getEvType();
            ddlType.DataTextField = "Ev_Type";
            ddlType.DataValueField = "Ev_Id";
            ddlType.DataBind();
            ListItem lis = new ListItem("Select", "-1");
            ddlType.Items.Insert(0, "Select");
        }

        private void ViewGV()
        {
            string id = ddlType.SelectedItem.Value;
            string dat = DateTime.Now.ToString("dd/MM/yyyy");
            DataTable tab = b.getEvtDet(int.Parse(id),dat);
            if (tab.Rows.Count > 0)
            {
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No Record Found..')</script>");
            }
        }

        protected void Register_Click(object sender, ImageClickEventArgs e)
        {
            GridViewRow r = (GridViewRow)((ImageButton)sender).Parent.Parent;
            int id = int.Parse(((ImageButton)sender).CommandArgument);
            //Label edId = (Label)r.FindControl("Evt_Id");
            Label edId = (Label)r.FindControl("Label1");
            edid = int.Parse(edId.Text);
            //Label etId = (Label)r.FindControl("Label2");
            //int etid = int.Parse(etId.Text);
            Label id3 = (Label)r.FindControl("Label3");
            id4=int.Parse(id3.ToolTip);
            usrid = b.getUsrId(name);
            string dat = DateTime.Now.ToString("dd/MM/yyyy");
            string sts="Pending";
            if (b.checkReg(usrid, edid) == 1)
            {
                Response.Write("<script>alert('Already registred..')</script>");
            }
            else
            {
                if (b.insertEvReg(usrid, edid, id4, dat, sts) == 1)
                {
                    Response.Write("<script>alert('Record inserted sucessfully..')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Error in insert record..')</script>");
                }
            }
        }

        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlType.SelectedIndex != 0)
            {
                ViewGV();
            }
        }

        protected void Query_Click(object sender, ImageClickEventArgs e)
        {
            GridViewRow r = (GridViewRow)((ImageButton)sender).Parent.Parent;
            int id = int.Parse(((ImageButton)sender).CommandArgument);
            //Label edId = (Label)r.FindControl("Evt_Id");
            Label edId = (Label)r.FindControl("Label1");
            edid = int.Parse(edId.Text);
            //Label etId = (Label)r.FindControl("Label2");
            //int etid = int.Parse(etId.Text);
            usrid = b.getUsrId(name);
            Session["edid"] = edid;
            Session["usrid"] = usrid;
            Response.Redirect("~/User/_frmQuery.aspx");
        }
    }
}