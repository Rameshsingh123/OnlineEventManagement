﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.User
{
    public partial class _frmCheckStatus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            usr=Session["User"].ToString();
            if (!this.IsPostBack)
            {
                getProf();
                getEvtType();
            }
        }

        BL b = new BL();
        string usr;

        private void getProf()
        {
            Image1.ImageUrl = b.getOrgPic(usr);
            Label1.Text = "Welcome " + b.getOrgName(usr);
            Label1.ForeColor = System.Drawing.Color.Brown;
        }

        private void getEvtType()
        {
            ddlType.DataSource = b.getEvType();
            ddlType.DataTextField = "EV_Type";
            ddlType.DataValueField = "Ev_Id";
            ddlType.DataBind();
            ListItem li = new ListItem("Select","-1");
            ddlType.Items.Insert(0,"Select");
        }

        private void getEvtName()
        {
            string id = ddlType.SelectedItem.Value;
            ddlName.DataSource = b.getEvtName(int.Parse(id));
            ddlName.DataTextField = "Ev_Name";
            ddlName.DataValueField = "Evt_Id";
            ddlName.DataBind();
            ListItem li = new ListItem("Select","-1");
            ddlName.Items.Insert(0,"Select");
        }

        private void ViewGV()
        {
            int usrId = b.getUsrId(usr);
            string evId = ddlType.SelectedItem.Value;
            string evtId = ddlName.SelectedItem.Value;
            DataTable tab = b.getRegStatus(usrId,evId,evtId);
            if (tab.Rows.Count > 0)
            {
                GridView1.Visible = true;
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else
            {
                GridView1.Visible = false;
                Response.Write("<script>alert('No records found..')</script>");
            }
        }

        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlType.SelectedIndex != 0)
            {
                getEvtName();
            }
        }

        protected void ddlName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlName.SelectedIndex != 0)
            {
                ViewGV();
            }
        }

        //private void DynTable()
        //{
        //    int usrId = b.getUsrId(usr);
        //    string evId = ddlType.SelectedItem.Value;
        //    string evtId = ddlName.SelectedItem.Value;
        //    DataTable dt = new DataTable();
        //    dt.Columns.Add("Status",typeof(string));
        //    dt.Columns.Add("Reason",typeof(string));
        //    DataTable dt1 = b.getRegStatus(usrId, evId, evtId);
        //    for (int i = 0; i < dt1.Rows.Count; i++)
        //    {
        //        dt.Rows.Add(dt1.Rows[i]["Status"].ToString(), dt1.Rows[i]["Reason"].ToString());
        //    }
        //    Table1.Controls.Add(dt);
        //}
    }
}