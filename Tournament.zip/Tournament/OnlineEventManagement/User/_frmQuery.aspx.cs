﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OnlineEventManagement.User
{
    public partial class _frmQuery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            usr = Session["User"].ToString();
            usrId = Session["usrid"].ToString();
            eId = Session["edid"].ToString();
            if (!this.IsPostBack)
            {
                getProf();
                ViewGV();
            }
        }

        BL b = new BL();
        string usr,usrId,eId;

        private void getProf()
        {
            Image1.ImageUrl = b.getOrgPic(usr);
            Label1.Text = "Welcome " + b.getOrgName(usr);
            Label1.ForeColor = System.Drawing.Color.Brown;
        }

        private void ViewGV()
        {
            int usrId = b.getUsrId(usr);
            DataTable tab = b.getQuery(usrId);
            if (tab.Rows.Count > 0)
            {
                GridView1.DataSource = tab;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('No record found..')</script>");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dat=DateTime.Now.ToString("dd/MM/yyyy");
            if (b.insertQuery(int.Parse(usrId), int.Parse(eId), txtQuery.Text, dat) == 1)
            {
                Response.Write("<script>alert('Query Inserted Sccessfully..')</script>");
            }
            else
            {
                Response.Write("<script>alert('Error in inserting..')</script>");
            }
            txtQuery.Text = "";
            ViewGV();
        }
    }
}